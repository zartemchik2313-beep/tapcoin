import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, MenuButtonWebApp, WebAppInfo
from telegram.ext import Application, CommandHandler, ContextTypes

BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
WEBAPP_URL = os.environ.get("WEBAPP_URL", "").strip()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not WEBAPP_URL.startswith("https://"):
        await update.message.reply_text(
            "TAPCOIN пока не опубликован. Владелец должен задать WEBAPP_URL — HTTPS-ссылку на игру."
        )
        return
    keyboard = [[InlineKeyboardButton("⛏️ Играть в TAPCOIN", web_app=WebAppInfo(url=WEBAPP_URL))]]
    await update.message.reply_text(
        "⚡ Добро пожаловать в TAPCOIN!\n\n"
        "Нажимай на монету, собирай игровые TAP-очки, улучшай силу тапа и автомайнинг.\n\n"
        "Важно: это игровая валюта, она не является деньгами.",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Команды TAPCOIN:\n/start — открыть игру\n/help — помощь\n\n"
        "Монеты в этой версии являются только игровыми очками."
    )

async def post_init(app: Application):
    if WEBAPP_URL.startswith("https://"):
        try:
            await app.bot.set_chat_menu_button(
                menu_button=MenuButtonWebApp(text="Играть", web_app=WebAppInfo(url=WEBAPP_URL))
            )
        except Exception as e:
            print(f"Не удалось настроить кнопку меню автоматически: {e}")

def main():
    if not BOT_TOKEN:
        raise RuntimeError("Не задан BOT_TOKEN. Добавьте токен бота в переменные окружения.")
    if not WEBAPP_URL.startswith("https://"):
        raise RuntimeError("Не задан WEBAPP_URL с HTTPS-ссылкой на опубликованную игру.")
    app = Application.builder().token(BOT_TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    print("TAPCOIN bot started.")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
